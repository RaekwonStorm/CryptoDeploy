console.log("app is started!")
