(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
var EventListener = require('../event.listener.js')
var eventListener = new EventListener();
chrome.extension.onMessage.addListener(function(req, sender, sendRes) {
  if (!eventListener[req.eventName]) return
  eventListener.emit(req.eventName, req);
})

var fillTheDOM = require('../utilities/walk.the.dom.js').fillTheDOM
var walkTheDomAndSubmit = require('../utilities/walk.the.dom.js').walkTheDomAndSubmit

var $email = $('input[type="email"]')
var $password = $('input[type="password"]')
var $username = $('input[type="username]')
var usernameArr = []
var $usernames = $('input[type="text"]').each(function() {
  var placeholder = $(this).attr('placeholder')
  var id = $(this).is('#username') || $(this).is('#email') || $(this).hasClass('username') || $(this).hasClass('email')
  if (placeholder && placeholder.toLowerCase().match(/(username)|(email)/) || id) usernameArr.push($(this))
})


if ($email.length || $password.length) {
  chrome.extension.sendMessage({ eventName: 'logins', currentUrl: window.location.href.toLowerCase() })
}

eventListener.on('loginRes', function(data) {
  var accToFill = data.logins[0];
  fillTheDOM($('input:not(input[type="submit"])'), ['username', 'name', 'email', 'user', 'em', 'log', 'sign'/*, 'in'*/], accToFill.username)
  fillTheDOM($('input:not(input[type="submit"])'), ['password', 'pswd', 'pass', 'pwd', 'pw'], accToFill.password)
})

eventListener.on('autoFill', function(data) {
  if (data.category == 'logins') {
    eventListener.emit('loginRes', {logins: [data.account]})
    if (data.account.name == 'facebook'){
      $('#loginbutton').trigger('click')
    }
    else {
      $('input[type="submit"]').each(function() {
        $(this).trigger('click')
      })
      $('button[type="submit"]').each(function() {
        $(this).trigger('click')
      })
      // walkTheDomAndSubmit('input', ['login', 'signin', 'log', 'sign', 'submit'])
      // walkTheDomAndSubmit('button', ['login', 'signin', 'log', 'sign', 'submit'])
    }
    if (data.account.name == 'google' || data.account.name == 'gmail' || data.account.name == 'tumblr') {
      // walkTheDomAndSubmit('input', ['login', 'signin', 'log', 'sign', 'submit'])
      setTimeout(function() {
        $('input[type="submit"]').each(function() {
          console.log('second click')
          $(this).trigger('click')
        })
      }, 1000)
    }
  } else if (data.category == 'credit cards'){
    fillTheDOM($('input:not(input[type="submit"]'), ['credit', 'card'], data.cardToFill.cardNumber)
    fillTheDOM($('input:not(input[type="submit"]'), ['ccv', 'security', 'cvv'], data.cardToFill.ccv)
    fillTheDOM($('input:not(input[type="submit"]'), ['name', 'hold'], data.cardToFill.firstName + ' ' + data.cardToFill.lastName)
    fillTheDOM($('input:not(input[type="submit"]'), ['exp', 'expiration', 'year', 'yea'], data.cardToFill.expiration.split('/')[1])
    fillTheDOM($('input:not(input[type="submit"]'), ['exp', 'expiration', 'month', 'mon'], data.cardToFill.expiration.split('/')[0])
    fillTheDOM($('input:not(input[type="submit"]'), ['exp', 'expiration', 'date'], data.cardToFill.expiration)

    var year = data.cardToFill.expiration.split('/')[1]
    if (year.length == 2) year = '20' + year;
    fillTheDOM($('select'), ['year', 'yea'], year)

    var month = data.cardToFill.expiration.split('/')[0];
    if (month.length == 1) month = '0' + month;
    console.log(month)
    fillTheDOM($('select'), [ 'month', 'mon'], month)
  }

})

$(document).ready(function() {

  chrome.extension.sendMessage({eventName: 'tabReady'})

})

},{"../event.listener.js":2,"../utilities/walk.the.dom.js":3}],2:[function(require,module,exports){
function EventListener () {}

EventListener.prototype.on = function (eventName, cb) {
  this[eventName] = this[eventName] ? this[eventName] : []
  this[eventName].push(cb)
}

EventListener.prototype.emit = function (eventName, data) {
  if (!this[eventName]) throw new Error('event not registered')
  this[eventName].forEach(function (cb) {
    cb(data);
  })
}

EventListener.prototype.clear = function (eventName) {
  this[eventName] = null;
}

module.exports = EventListener;

},{}],3:[function(require,module,exports){
function fillTheDOM ($tree, classes, value){
  classes.forEach(function (name){
    var check = new RegExp(name.toLowerCase());
    $.each($tree, function (index, element){
      var elemName = element.getAttribute('name') ? element.getAttribute('name') : ''
      // var elemId = element.id ? element.id : ''
      if (!$(element).is(':submit') && $(element).is('input') && element.id.toLowerCase().split(' ').join('').match(check) || element.className.toLowerCase().split(' ').join('').match(check) || elemName.match(check) || (isValidType(name) && $(element).is(':' + name))){
        $(element).val(value)
      }
    })
  })
}

function walkTheDomAndSubmit (category, classes, siteName){
  classes.forEach(function (name){
    var check = new RegExp(name.toLowerCase());
    // $('[class*='+ name +']').trigger('click')
    $(category + '[type="submit"]').each(function (ind, elem){
      var elemName = elem.getAttribute('name') ? elem.getAttribute('name') : ''
      var elemVal = elem.getAttribute('value') ? elem.getAttribute('value') : ''
      if (/*($(elem).is('input') || $(elem).is('button')) && */elem.id.toLowerCase().split(' ').join('').match(check) || elem.className.toLowerCase().split(' ').join('').match(check) || elemName.match(check) || elemVal.match(check)){
        $(elem).trigger('click')
      }
    })
  })
}

function isValidType(name){
  if (name == 'text' || name == 'password' ) return true
  return false
}
module.exports = { fillTheDOM: fillTheDOM, walkTheDomAndSubmit: walkTheDomAndSubmit}

},{}]},{},[1]);
